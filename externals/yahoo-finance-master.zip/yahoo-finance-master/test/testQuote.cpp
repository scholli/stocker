#include <string>
#include <sstream>
#include <iostream>

#include "quote.hpp"
#include "time_utils.hpp"


int main() {
    {
        Quote *quote = new Quote("^GSPC");
        std::time_t epoch = dateToEpoch("2017-12-01") + 72000;
        std::string csv = quote->getHistoricalCsv(epoch, epoch, "1d");

        // Test the two CSV lines
        std::istringstream csvStream(csv);
        std::string line, expected;

        std::getline(csvStream, line);
        expected = "Date,Open,High,Low,Close,Adj Close,Volume";

        std::getline(csvStream, line);
        expected = "2017-12-01,2645.100098,2650.620117,2605.520020,2642.219971,2642.219971,3942320000";

    }
    // Euro Stoxx 50
    {
        Quote *quote = new Quote("BAS.DE");
        quote->getHistoricalSpots("2011-12-01", "2018-12-04", "1d");

        // Test the spot at 2017-12-01
        Spot spot = quote->getSpot("2017-12-01");
        for (size_t i = 0; i != quote->nbSpots(); ++i) {
            auto s = quote->getSpot(i);
            std::cout << s.getDate() << " : " << s.getClose() << std::endl;
        }
        std::cout << "2017-12-01 " << spot.getClose() << std::endl;;

        // Test the spot at 2017-12-04
        spot = quote->getSpot("2017-12-04");

    }
    {
        // EUR/USD rate
        Quote *quote = new Quote("EURUSD=X");
        quote->getHistoricalSpots("2017-12-01", "2017-12-31", "1d");

        // Test the spot at 2017-12-08
        Spot spot = quote->getSpot("2017-12-08");
        std::cout << "2017-12-08 " << spot.getOpen() << std::endl;;
        std::cout << "2017-12-08 " << spot.getHigh() << std::endl;;
        std::cout << "2017-12-08 " << spot.getLow() << std::endl;;
        std::cout << "2017-12-08 " <<spot.getClose() << std::endl;;

        // Test the spot at 2017-12-21
        spot = quote->getSpot("2017-12-21");
        std::cout << "2017-12-21 " << spot.getOpen() << std::endl;;
        std::cout << "2017-12-21 " << spot.getHigh() << std::endl;;
        std::cout << "2017-12-21 " << spot.getLow() << std::endl;;
        std::cout << "2017-12-21 " << spot.getClose() << std::endl;;
    }
    {
        // EUR/AUD rate
        Quote *quote = new Quote("EURAUD=X");
        quote->getHistoricalSpots("2017-12-01", "2017-12-31", "1d");

        // Test the spot at 2017-12-13
        Spot spot = quote->getSpot("2017-12-13");
        std::cout << "2017-12-13 " << spot.getOpen() << std::endl;;
        std::cout << "2017-12-13 " << spot.getHigh() << std::endl;;
        std::cout << "2017-12-13 " << spot.getLow() << std::endl;;
        std::cout << "2017-12-13 " << spot.getClose() << std::endl;;

        // Test the spot at 2017-12-27
        spot = quote->getSpot("2017-12-27");
    }
}
