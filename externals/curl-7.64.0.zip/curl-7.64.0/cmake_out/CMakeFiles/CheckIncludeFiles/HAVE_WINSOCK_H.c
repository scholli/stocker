/* */
#include <windows.h>
#include <winsock.h>


int main(void){return 0;}

