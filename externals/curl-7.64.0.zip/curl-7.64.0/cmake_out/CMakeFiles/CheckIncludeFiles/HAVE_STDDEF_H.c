/* */
#include <windows.h>
#include <winsock.h>
#include <ws2tcpip.h>
#include <winsock2.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/utime.h>
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <io.h>
#include <locale.h>
#include <setjmp.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <process.h>
#include <stddef.h>


int main(void){return 0;}

