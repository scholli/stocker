/* */
#include <windows.h>
#include <winsock.h>
#include <ws2tcpip.h>
#include <winsock2.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/utime.h>
#include <assert.h>
#include <des.h>


int main(void){return 0;}

