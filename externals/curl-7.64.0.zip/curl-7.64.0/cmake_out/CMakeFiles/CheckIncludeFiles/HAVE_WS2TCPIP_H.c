/* */
#include <windows.h>
#include <winsock.h>
#include <ws2tcpip.h>


int main(void){return 0;}

