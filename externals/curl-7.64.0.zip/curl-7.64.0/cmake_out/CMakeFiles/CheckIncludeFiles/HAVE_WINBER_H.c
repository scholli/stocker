/* */
#include <winber.h>


int main(void){return 0;}

